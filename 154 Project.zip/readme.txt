load Main2.jff

Symbols
i = 1
z = 0

R = result
w = WIP
M = Marked for y

